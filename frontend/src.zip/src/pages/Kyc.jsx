import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Check, Clock, ScanText, Upload, X } from "lucide-react";
import { api } from "../lib/api.js";
import { useAuth } from "../lib/auth.jsx";
import { date } from "../lib/format.js";
import { DocPicker } from "../components/ImagePicker.jsx";
import { Loading, Notice, Pill, Spinner, useToast } from "../components/ui.jsx";

function mask(n = "") {
  const d = String(n).replace(/\s/g, "");
  return d.length >= 4 ? `XXXX XXXX ${d.slice(-4)}` : n || "—";
}

export function OcrSummary({ ocr }) {
  if (!ocr) return null;
  const a = ocr.aadhaar || {};
  const p = ocr.pan || {};
  return (
    <div className="ocr">
      <div className="panel-flat">
        <h3 style={{ fontSize: "1rem", marginBottom: "0.6rem" }}>Read from Aadhaar</h3>
        <dl>
          <dt>Name</dt><dd>{a.name || "—"}</dd>
          <dt>Number</dt><dd>{mask(a.aadhaarNumber)}</dd>
          <dt>Date of birth</dt><dd>{a.dob || "—"}</dd>
          <dt>Gender</dt><dd>{a.gender || "—"}</dd>
        </dl>
      </div>
      <div className="panel-flat">
        <h3 style={{ fontSize: "1rem", marginBottom: "0.6rem" }}>Read from PAN</h3>
        <dl>
          <dt>Name</dt><dd>{p.name || "—"}</dd>
          <dt>PAN</dt><dd>{p.panNumber || "—"}</dd>
          <dt>Father's name</dt><dd>{p.fatherName || "—"}</dd>
          <dt>Date of birth</dt><dd>{p.dob || "—"}</dd>
        </dl>
      </div>
    </div>
  );
}

export default function Kyc() {
  const { user } = useAuth();
  const toast = useToast();
  const [kyc, setKyc] = useState(null);
  const [error, setError] = useState("");
  const [files, setFiles] = useState({ aadhaarFront: null, aadhaarBack: null, panCard: null });
  const [busy, setBusy] = useState(false);
  const [redo, setRedo] = useState(false);

  const load = () => api.getKyc().then((r) => setKyc(r.data)).catch((e) => { setError(e.message); setKyc({ status: "NOT_SUBMITTED" }); });
  useEffect(() => { load(); }, []);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError("");
    const form = new FormData();
    Object.entries(files).forEach(([k, f]) => form.append(k, f));
    try {
      await api.submitKyc(form);
      toast("Documents submitted for review");
      setRedo(false);
      setFiles({ aadhaarFront: null, aadhaarBack: null, panCard: null });
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  if (!kyc) return <Loading label="Checking verification" />;

  const s = kyc.status;
  const submitted = s !== "NOT_SUBMITTED";
  const showForm = !submitted || s === "REJECTED" || redo;
  const ready = files.aadhaarFront && files.aadhaarBack && files.panCard;
  const ocrDone = kyc.ocrStatus === "COMPLETED";
  const ocrFailed = kyc.ocrStatus === "FAILED";

  const stepClass = (done, now, fail) => `kyc-step ${fail ? "fail" : done ? "done" : now ? "now" : ""}`;
  const icon = (done, now, fail) => (fail ? <X /> : done ? <Check /> : now ? <Clock /> : null);

  return (
    <div className="page page-narrow">
      <div className="page-head">
        <div>
          <h1>Verification</h1>
          <p>
            {user.role === "FARMER"
              ? "Farmers need an approved KYC before listing crops. It protects buyers and keeps the market honest."
              : "Verified accounts are easier for farmers to trust."}
          </p>
        </div>
        {submitted && <Pill status={s} />}
      </div>

      <div className="panel" style={{ marginBottom: "1.25rem" }}>
        <div className="kyc-steps">
          <div className={stepClass(submitted, !submitted)}>
            <span className="kyc-dot">{icon(submitted, !submitted) || <Upload />}</span>
            <div>
              <strong>Upload Aadhaar and PAN</strong>
              <div className="small muted">{submitted && kyc.lastSubmittedAt ? `Submitted ${date(kyc.lastSubmittedAt)}` : "Photos of both sides of Aadhaar and the front of PAN"}</div>
            </div>
          </div>
          <div className={stepClass(ocrDone, submitted && !ocrDone && !ocrFailed, ocrFailed)}>
            <span className="kyc-dot">{icon(ocrDone, submitted && !ocrDone && !ocrFailed, ocrFailed) || <ScanText />}</span>
            <div>
              <strong>Details read automatically</strong>
              <div className="small muted">
                {ocrFailed ? "We couldn't read the documents. A reviewer will check them by hand, or you can upload clearer photos."
                  : ocrDone ? `Read with ${Math.round(kyc.ocrConfidence || 0)}% confidence` : "Name, number and date of birth are extracted"}
              </div>
            </div>
          </div>
          <div className={stepClass(s === "APPROVED", s === "PENDING", s === "REJECTED")}>
            <span className="kyc-dot">{icon(s === "APPROVED", s === "PENDING", s === "REJECTED") || <Check />}</span>
            <div>
              <strong>Reviewed by AgriShield</strong>
              <div className="small muted">
                {s === "APPROVED" ? `Approved ${date(kyc.verifiedAt)}` : s === "REJECTED" ? "Not approved, see the reason below" : s === "PENDING" ? "Usually within one working day" : "Happens after you submit"}
              </div>
            </div>
          </div>
        </div>
      </div>

      {s === "APPROVED" && (
        <Notice tone="ok" title="You're verified" action={user.role === "FARMER" && <Link to="/app/listings/new" className="btn btn-sm btn-primary">List a crop</Link>}>
          {user.role === "FARMER" ? "You can now list crops in the market." : "Farmers will see you as a verified buyer."}
        </Notice>
      )}
      {s === "REJECTED" && (
        <Notice tone="bad" title="Verification wasn't approved">
          {kyc.rejectionReason || "No reason was given."} Upload new photos below to try again.
        </Notice>
      )}

      {submitted && kyc.ocrData && (
        <section className="stack" style={{ marginTop: "1.25rem" }}>
          <h2 style={{ fontSize: "var(--step-1)" }}>What we read</h2>
          <OcrSummary ocr={kyc.ocrData} />
          {!showForm && s !== "APPROVED" && (
            <button className="btn btn-link small" onClick={() => setRedo(true)} style={{ justifySelf: "start" }}>
              Something's wrong? Upload new photos
            </button>
          )}
        </section>
      )}

      {showForm && (
        <form onSubmit={submit} className="panel stack" style={{ marginTop: "1.25rem", "--gap": "1.25rem" }}>
          <h2 style={{ fontSize: "var(--step-1)" }}>{submitted ? "Upload new photos" : "Upload your documents"}</h2>
          {error && <Notice tone="bad" title="Couldn't submit">{error}</Notice>}
          <div className="doc-grid" style={{ alignItems: "start" }}>
            <DocPicker label="Aadhaar, front" file={files.aadhaarFront} onChange={(f) => setFiles({ ...files, aadhaarFront: f })} />
            <DocPicker label="Aadhaar, back" file={files.aadhaarBack} onChange={(f) => setFiles({ ...files, aadhaarBack: f })} />
            <DocPicker label="PAN card" file={files.panCard} onChange={(f) => setFiles({ ...files, panCard: f })} />
          </div>
          <p className="small faint">Only AgriShield reviewers see these images. Your Aadhaar number is never shown to buyers.</p>
          <div className="row" style={{ justifyContent: "flex-end" }}>
            {redo && <button type="button" className="btn btn-ghost" onClick={() => setRedo(false)}>Cancel</button>}
            <button className="btn btn-ink" disabled={!ready || busy}>
              {busy ? <><Spinner /> Reading documents…</> : "Submit for review"}
            </button>
          </div>
          {busy && <p className="small muted" role="status">Reading the text on your documents can take up to a minute. Keep this page open.</p>}
        </form>
      )}
    </div>
  );
}
